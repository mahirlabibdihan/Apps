
import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (60,40)
import pygame 
import sys
from pygame import mixer
pygame.init()
pygame.font.init()
pygame.mouse.set_visible(False);
screen = pygame.display.set_mode((691,1007));

pygame.display.set_icon(pygame.image.load('tennis.ico'));

#pygame.mouse.set_cursor(*pygame.cursors.diamond)

ground=pygame.image.load('ground.jpg');
ground=pygame.transform.scale(ground, (691, 1007));
pygame.display.set_caption("Tennis");

ball=pygame.image.load('ball.png');

dihu=pygame.image.load('dihu.png');
shupto=pygame.image.load('shupto.png');
shup=pygame.image.load('shup.png');
dihu=pygame.transform.scale(dihu, (100, 100))
shupto=pygame.transform.scale(shupto, (100, 150))
shup=pygame.transform.scale(shup, (120, 150))
bat1=pygame.image.load('bat1.png');
bat2=pygame.image.load('bat2.png');
bat_1=pygame.image.load('bat_1.png')
bat_2=pygame.image.load('bat_2.png')

#pygame.mixer.Channel(0).play(pygame.mixer.Sound('music.wav'))
mixer.music.load('music.wav');
mixer.music.play(-1)


p=q=bx=dirx=diry=score=Dir=0;
hit=0;
r=340;
by = 895;

gameover = 0;
start= False;

while True:

  screen.blit(ground,(0,0))
  p,q= pygame.mouse.get_pos()
  if(p>660): p=660

  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      pygame.quit();
      sys.exit(); 

    elif event.type == pygame.MOUSEBUTTONDOWN:
      if start==False:
        start = True
        hit=1;
        pygame.mixer.Channel(0).play(pygame.mixer.Sound('hit.wav'))
        diry = -3
        bx = p

    elif event.type == pygame.KEYDOWN:
      if event.key == pygame.K_LEFT:
        Dir=-5
      elif event.key == pygame.K_RIGHT:
        Dir=5
      elif event.key == pygame.K_ESCAPE:
        pygame.quit();
        sys.exit(); 

    elif event.type == pygame.KEYUP:
      Dir=0


  if(r+Dir>-50 and r+Dir<630): 
    r+=Dir

  
  if(hit):
    if(hit%2==1):
      screen.blit(bat_1,(p-120,870));
      screen.blit(bat2,(r,0));
      hit+=2;
    else:
      screen.blit(bat1,(p-60,870));
      screen.blit(bat_2,(r,0));
      hit+=2;
    if(hit>24): hit=0;

  else:
    screen.blit(bat1,(p-60,870));
    screen.blit(bat2,(r,0));
  screen.blit(dihu ,(p-80,880));
  screen.blit(shupto,(r+50,-30));

  if(dirx>7): dirx=7
  if(dirx<-7): dirx=-7 
  bx+=dirx; by+=diry;

  if start: a=bx
  else: a=p
  screen.blit(ball,(a,by))



#bat1
  if (diry>0 and by>=890 and by<=950):
    if(bx>=p-30 and bx<=p-15):
        if dirx>=0: dirx=-dirx-4;
        else: dirx=-dirx-7;
        diry=-2; hit=1;
    elif(bx>p-15 and bx<=p):
        if dirx>=0: dirx=-dirx-3;
        else: dirx=-dirx-6;
        diry=-2; hit=1;

    elif(bx>p and bx<=p+10):
        if dirx>=0: dirx=-dirx-2;
        else: dirx=-dirx-5;
        diry=-4; hit=1;

    elif(bx>p+10 and bx<=p+20):
        if dirx>=0: dirx=-dirx-1;
        else: dirx=-dirx-4;
        diry=-4; hit=1;

    elif(bx>p+20 and bx<=p+30):
        diry=-diry; hit=1;

    elif(bx>p+30 and bx<=p+40):
        if dirx>=0: dirx=-dirx+4;
        else: dirx=-dirx+1;
        diry=-4; hit=1;
      
    elif(bx>p+40 and bx<=p+50):
        if dirx>=0: dirx=-dirx+5;
        else: dirx=-dirx+2;
        diry=-4; hit=1;

    elif(bx>p+50 and bx<=p+65):
        if dirx>=0: dirx=-dirx+6;
        else: dirx=-dirx+3;
        diry=-2;hit=1;

    elif(bx>p+65 and bx<=p+80):
        if dirx>=0: dirx=-dirx+7;
        else: dirx=-dirx+4;
        diry=-2;hit=1;

    elif(by>1007): gameover= 2;


#bat2
  elif(diry<0 and by<=85 and by>=25): 

    if(bx>=r-40 and bx<=-25):
      if dirx>=0: dirx=-dirx-4;
      else: dirx=-dirx-7;
      diry=2;hit=2;

    elif(bx>r-25 and bx<=r-10):
        if dirx>=0: dirx=-dirx-3;
        else: dirx=-dirx-6;
        diry=2;hit=2;
 

    elif(bx>r-10 and bx<=r):
        if dirx>=0: dirx=-dirx-2;
        else: dirx=-dirx-5;
        diry=4;hit=2;
        
    elif(bx>r and bx<=r+10):
        if dirx>=0: dirx=-dirx-1;
        else: dirx=-dirx-4;
        diry=4;hit=2;

    elif(bx>r+10 and bx<=r+20): diry=-diry;hit=2;
      
    elif(bx>r+20 and bx<=r+30):
        if dirx>=0: dirx=-dirx+4;
        else: dirx=-dirx+1;
        diry=4;hit=2;
      
    elif(bx>r+30 and bx<=r+40):
        if dirx>=0: dirx=-dirx+5;
        else: dirx=-dirx+2;
        diry=4;hit=2;

    elif(bx>r+40 and bx<=r+55):
        if dirx>=0: dirx=-dirx+6;
        else: dirx=-dirx+3;
        diry=2;hit=2;

    elif(bx>r+55 and bx<=r+70):
      if dirx>=0: dirx=-dirx+7;
      else: dirx=-dirx+4;
      diry=2;hit=2;

    elif(by<-50): gameover= 1;
 
  elif(dirx>0 and bx>660)or(dirx<0 and bx<0): 
    dirx=-dirx

  elif(diry>0 and by>=1007): gameover=2   

  elif(diry<0 and by<=-50): gameover=1  
  if(hit<3 and hit>0):
    pygame.mixer.Channel(0).play(pygame.mixer.Sound('hit.wav'))

  if(gameover):
    pygame.mixer.Channel(0).play(pygame.mixer.Sound('cheer.wav')) 
    pygame.mouse.set_visible(True);
    if(gameover==1):
      win1=pygame.image.load('ground1.jpg');
      screen.blit(win1,(0,0))
    elif(gameover==2):
      win2=pygame.image.load('ground2.jpg');
      screen.blit(win2,(0,0))
    pygame.display.update()
    while True:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          pygame.quit();
          sys.exit();
        elif event.type == pygame.MOUSEBUTTONDOWN or event.type==pygame.KEYDOWN:
          pygame.quit();
          sys.exit();

  print(dirx);

  pygame.display.update()

