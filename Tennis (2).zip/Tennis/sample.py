

import pygame 

pygame.init()
pygame.font.init()
screen = pygame.display.set_mode((691,1007));




ball=pygame.image.load('ball.png');


bat1=pygame.image.load('bat1.png');
bat2=pygame.image.load('bat2.png');


p=q=bx=dirx=diry=score=Dir=0;
hit=0;
r=340;
by = 895;

pointx=p
pointy=895;
gameover = 0;
start= False;

while True:

  screen.fill((255,255,255));
  p,q= pygame.mouse.get_pos()
  if(p>660): p=660

  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      pygame.quit();
      sys.exit(); 

    elif event.type == pygame.MOUSEBUTTONDOWN:
      if start==False:
        start = True
        diry = -3
        bx = p
        pointx=p
        r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;

   

  screen.blit(bat1,(p-60,870));
  screen.blit(bat2,(r,0));



  bx+=dirx; by+=diry;

  if start: a=bx
  else: a=p
  screen.blit(ball,(a,by))



#bat1
  if (diry>0 and by>=890 and by<=950):
    if(bx>=p-30 and bx<=p-15):
        dirx=-3; 
        diry=-1;pointy=by;
        pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;
    elif(bx>p-15 and bx<=p):
        dirx=-2;pointy=by;
        diry=-1; pointx=bx;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690; 

    elif(bx>p and bx<=p+10):
        dirx=-2
        diry=-2;pointy=by; pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;

    elif(bx>p+10 and bx<=p+20):
        dirx=-1;
        diry=-2;pointy=by; pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;

    elif(bx>p+20 and bx<=p+30):
        diry=-diry; pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;

    elif(bx>p+30 and bx<=p+40):
        dirx=1;
        diry=-2;pointy=by; pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;
      
    elif(bx>p+40 and bx<=p+50):
        dirx=2
        diry=-2;pointy=by; pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;

    elif(bx>p+50 and bx<=p+65):
        dirx=2;
        diry=-1;pointy=by;pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;

    elif(bx>p+65 and bx<=p+80):
        dirx=3; 
        diry=-1;pointy=by;pointx=bx ;r=((((pointy/diry)*dirx)%690)+(690-pointx))%690;


    elif(by>1007): gameover= 2;


  elif(diry<0 and by<0): diry=-diry
  elif(dirx>0 and bx>660)or(dirx<0 and bx<0): 
    dirx=-dirx

  elif(diry>0 and by>=1007): gameover=2   

  elif(diry<0 and by<=-50): gameover=1  

  
  


  
  if(gameover):
    while True:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          pygame.quit();
          sys.exit();
        elif event.type == pygame.MOUSEBUTTONDOWN or event.type==pygame.KEYDOWN:
          pygame.quit();
          sys.exit();


  pygame.display.update()

