import pygame 
from pygame import mixer
pygame.init()

screen = pygame.display.set_mode((691,1007))

pygame.display.set_icon(pygame.image.load('tennis.png'))

ground=pygame.image.load('ground.jpg')
ground=pygame.transform.scale(ground, (691, 1007))
pygame.display.set_caption("Tennis")

ball=pygame.image.load('ball.png')
bat1=pygame.image.load('bat1.png')
bat2=pygame.image.load('bat2.png')

mixer.music.load('music.wav')
mixer.music.play(-1)


p=q=bx=dirx=diry=score=Dir=0
r=340
by = 905

gameover = 0
start= False 



while True:

  screen.blit(ground,(0,0))
  p,q= pygame.mouse.get_pos()
  if(p>660): p=660

  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      pygame.quit() 

    elif event.type == pygame.MOUSEBUTTONDOWN:
      if start==False:
        start = True
        diry = -4
        bx = p

    elif event.type == pygame.KEYDOWN:
      if event.key == pygame.K_LEFT:
        Dir=-5
      elif event.key == pygame.K_RIGHT:
        Dir=5

    elif event.type == pygame.KEYUP:
      Dir=0


  if(r+Dir>-50 and r+Dir<620): 
    r+=Dir
  screen.blit(bat1,(p-60,880)) 
  screen.blit(bat2,(r,0)) 

  bx+=dirx
  by+=diry

  if(bx<0): bx=0
  elif(bx>650): bx=650

  if(by<-50): by=-50
  elif(by>1007): by=1007   

  if start: a=bx
  else: a=p
  screen.blit(ball,(a,by))

  if diry>0 and by>=890 and by<=960:
    if(bx>=p-25 and bx<=p-10):
        dirx=-6
        diry=-2
        score+=10

    elif(bx>p-10 and bx<=p+5):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=-2
        score+=10

    elif(bx>p+5 and bx<=p+15):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=-4
        score+=10

    elif(bx>p+15 and bx<=p+25):
        if dirx>0: dirx=1
        else: dirx=-2
        diry=-4
        score+=10

    elif(bx>p+25 and bx<=p+35):
        diry=-diry
        score+=10

    elif(bx>p+35 and bx<=p+45):
        if dirx>=0: dirx=1
        else: dirx=-2
        diry=-4
        score+=10
      
    elif(bx>p+45 and bx<=p+55):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=-4
        score+=10

    elif(bx>p+55 and bx<=p+70):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=-2
        score+=10

    elif(bx>p+70 and bx<=p+85): 
        dirx=6
        diry=-2
        score+=10

    elif(by==1007): 
        gameover= 2;

  elif(diry<0 and by<=90 and by>=20): 
    if(bx>=r-40 and bx<=-25): 
        dirx=-6
        diry=2
        score+=10

    elif(bx>r-25 and bx<=r-10):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=2
        score+=10

    elif(bx>r-10 and bx<=r):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=4
        score+=10

    elif(bx>r and bx<=r+10):
        if dirx>0: dirx=1
        else: dirx=-2
        diry=4
        score+=10

    elif(bx>r+10 and bx<=r+20):
        diry=-diry
        score+=10

    elif(bx>r+20 and bx<=r+30):
        if dirx>=0: dirx=1
        else: dirx=-2
        diry=4
        score+=10
      
    elif(bx>r+30 and bx<=r+40):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=4
        score+=10

    elif(bx>r+40 and bx<=r+55):
        if dirx>=0: dirx=2
        else: dirx=-4
        diry=2
        score+=10

    elif(bx>r+55 and bx<=r+70): 
        dirx=6
        diry=2
        score+=10

    elif(by==-50): 
        gameover= 1;


  elif(dirx>0 and bx==650): dirx=-dirx

  elif(dirx<0 and bx==0): dirx=-dirx

  elif(diry>0 and by>=1007): gameover=2   

  elif(diry<0 and by<=-50): gameover=1   


  if(gameover): 
    font = pygame.font.Font('freesansbold.ttf',50)
    result = font.render("PLAYER "+str(gameover)+" WINS",True,(255,0,0))
    screen.blit(result,(150,505))
    pygame.display.update()
    while True:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          pygame.quit() 
        elif event.type == pygame.MOUSEBUTTONDOWN or event.type==pygame.KEYDOWN:
          pygame.quit()

  pygame.display.update()

